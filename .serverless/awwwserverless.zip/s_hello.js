
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ed42311',
  applicationName: 'awwserverless',
  appUid: 'MzD9288yDpdLwYMt6m',
  orgUid: '0ZK2Pw52NXKG2j6XvS',
  deploymentUid: '1f97d41d-f019-43d5-a3d6-0f30c7957ca8',
  serviceName: 'awwwserverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.0.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'awwwserverless-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}